package com.kishore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.adventnet.beans.criteriatable.Criteria;
//import com.adventnet.ds.query.Column;
//import com.adventnet.ds.query.Criteria;
//import com.adventnet.ds.query.QueryConstants;
//import com.adventnet.ds.query.SelectQuery;
//import com.adventnet.ds.query.SelectQueryImpl;
//import com.adventnet.ds.query.Table;
//import com.adventnet.persistence.DataAccess;
//import com.adventnet.persistence.DataObject;
//import com.adventnet.persistence.Row;
import java.io.PrintWriter;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;

public class Database2 {
	

	public Result dataFetech1(int id) {
		Criteria c = new Criteria(new Column("QueryTitle", "TYPE_ID"), id, QueryConstants.EQUAL);
		

		Result map = null;
		DataObject d;
		try {
			
			d = DataAccess.get("QueryTitle", c);
			Iterator<?> it = d.getRows("QueryTitle");
			while (it.hasNext()) {
				// returns a row
				Row r = (Row) it.next();
				String chart_type = (String) r.get(2);
				String search_key = (String) r.get(3);
				String query_type = (String) r.get(4);
				map = new Result(chart_type , search_key , query_type);
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return map;
	}
	
	public ArrayList<String> dataFetch2(String logFormat) {
		
		Criteria c = new Criteria(new Column("RegexDetails", "LOG_ID"), 1, QueryConstants.EQUAL);
		
//		Criteria c = new Criteria(new Column("QueryTitle", "TYPE_ID"), 1, QueryConstants.EQUAL);
		
		
		DataObject d;
		ArrayList<String> tempArr = new ArrayList<String>();
		
		try {
			
			d = DataAccess.get("RegexDetails", c);
			Iterator<?> it = d.getRows("RegexDetails");
			
//			d = DataAccess.get("QueryTitle", c);
//			Iterator<?> it = d.getRows("QueryTitle");
			
			while (it.hasNext()) {
				
				Row r = (Row) it.next();
//				String chart_type = (String) r.get(2);
//				String search_key = (String) r.get(3);
//				String query_type = (String) r.get(4);
//				tempArr.add(chart_type);
//				tempArr.add(search_key);
//				tempArr.add(query_type);
				String temp = "" + r.get(3);
				tempArr.add(temp);
//				System.out.println(it.next());
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return tempArr;
	}
}
