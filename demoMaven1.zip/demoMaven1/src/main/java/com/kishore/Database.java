package com.kishore;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

class Database {

	
	public Result dataFetech(int id) {
		
		
		Connection connection = null;
		ResultSet resultSet = null;
		Result map = null;
		
		try {
			
			Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/demoDB","postgres","123");
			
			if (connection != null) {
				
				System.out.println("Connection successfully connected");
			}
			else {
				System.out.println("Connection not connected");
			}
			
			String sql = "SELECT * FROM querytable WHERE ID=" + id;
			
			PreparedStatement statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			
			while (resultSet.next()) {
				
				String chart_type = resultSet.getString("chart_type");
				String search_key = resultSet.getString("search_key");
				String query = resultSet.getString("query");
				String query_type = resultSet.getString("query_type");
//				System.out.printf("The chart is %s and the search term is %s\n", chart_type, search_key);
				map = new Result(chart_type , search_key, query_type);
			}
			
		}
		catch (Exception e) {
			System.out.println(e);
		}
//		System.out.println(map.chart_type);
		return map;
	}
}

class Result {
	public String chart_type;
	public String search_key;
	public String query_type;

	public Result(String chart_type, String search_key, String query_type) {
		this.chart_type = chart_type;
		this.search_key = search_key;
		this.query_type = query_type;
	}
}

