package com.kishore;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.concurrent.ThreadLocalRandom;

import com.adventnet.authentication.AAAUSER;
import com.adventnet.authentication.AAALOGIN;
import com.adventnet.authentication.AAAACCOUNT;
import com.adventnet.authentication.AAAPASSWORD;
import com.adventnet.authentication.AAAACCPASSWORD;
import com.adventnet.authentication.AAAACCOWNERPROFILE;
import com.adventnet.authentication.AAAAUTHORIZEDROLE;
import com.adventnet.authentication.PasswordException;
import com.adventnet.authentication.util.AuthUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.Persistence;
import com.adventnet.authorization.service.AuthorizationService;
import com.zoho.authentication.DefaultAuthHandler;

public class check2 extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String loginName = "12";
		String firstName = "12";
		String middleName = "";
		String lastName = "";
		String serviceName = "System";
		String accAdminProfile = "Profile 1";
		String password = "Kish@2000";
		String passwordProfile = "Profile 1";
		String algorithm = "Bcrypt";
		String salt = "";

		ProductAuthHandler p = new ProductAuthHandler();
		salt = p.generateSalt(algorithm);
		String hashedPassword = p.getHashedPassword(password, salt, algorithm);
		System.out.println("salt: " + salt);
		System.out.println("hashedPassword: " + hashedPassword);

		try {
			Persistence persistence = (Persistence) BeanUtil.lookup("Persistence");
			DataObject dobj = persistence.constructDataObject();
			Row userRow = new Row(AAAUSER.TABLE);
			userRow.set(AAAUSER.FIRST_NAME, firstName);

			dobj.addRow(userRow);

			Row loginRow = new Row(AAALOGIN.TABLE);
			loginRow.set(AAALOGIN.NAME, loginName);
			dobj.addRow(loginRow);

			Row accRow = new Row(AAAACCOUNT.TABLE);
			accRow.set(AAAACCOUNT.SERVICE_ID, AuthUtil.getServiceId(serviceName));
			accRow.set(AAAACCOUNT.ACCOUNTPROFILE_ID, AuthUtil.getAccountProfileId(accAdminProfile));
			dobj.addRow(accRow);

			Row passwordRow = new Row(AAAPASSWORD.TABLE);
			passwordRow.set(AAAPASSWORD.PASSWORD, password);
			passwordRow.set(AAAPASSWORD.PASSWDPROFILE_ID, AuthUtil.getPasswordProfileId(passwordProfile));
			dobj.addRow(passwordRow);

			Row accPassRow = new Row(AAAACCPASSWORD.TABLE);
			accPassRow.set(AAAACCPASSWORD.ACCOUNT_ID, accRow.get(AAAACCOUNT.ACCOUNT_ID));
			accPassRow.set(AAAACCPASSWORD.PASSWORD_ID, passwordRow.get(AAAPASSWORD.PASSWORD_ID));
			dobj.addRow(accPassRow);

//    	// to assign roles - optional
//    	Row authRoleRow1 = new Row(AAAAUTHORIZEDROLE.TABLE);
//    	authRoleRow1.set(AAAAUTHORIZEDROLE.ACCOUNT_ID, accRow.get(AAAACCOUNT.ACCOUNT_ID));
//    	authRoleRow1.set(AAAAUTHORIZEDROLE.ROLE_ID, AuthUtil.getRoleId(role1));
//    	dobj.addRow(authRoleRow1);
//
//    	Row authRoleRow2 = new Row(AAAAUTHORIZEDROLE.TABLE);
//    	authRoleRow2.set(AAAAUTHORIZEDROLE.ACCOUNT_ID, accRow.get(AAAACCOUNT.ACCOUNT_ID));
//    	authRoleRow2.set(AAAAUTHORIZEDROLE.ROLE_ID, AuthUtil.getRoleId(role2));
//    	dobj.addRow(authRoleRow2);

//			// to permit this user to create another user - optional
//			int noOfSubAccounts = -1; // -1 to create unlimited users, 0 - for no user, n - to create n user accounts
//			Row accOwnerProfileRow = new Row(AAAACCOWNERPROFILE.TABLE);
//			accOwnerProfileRow.set(AAAACCOWNERPROFILE.ACCOUNT_ID, accRow.get(AAAACCOUNT.ACCOUNT_ID));
//			accOwnerProfileRow.set(AAAACCOWNERPROFILE.ALLOWED_SUBACCOUNT, noOfSubAccounts);
//			dobj.addRow(accOwnerProfileRow);

			AuthUtil.createUserAccount(dobj);
		} catch (PasswordException pe) {
			pe.printStackTrace();
		} catch (DataAccessException dae) {
			dae.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

class ProductAuthHandler extends DefaultAuthHandler {
	@Override
	public String getHashedPassword(String password, String salt, String algorithm) {
		if (algorithm.equalsIgnoreCase("Bcrypt")) {
//			return scramHash(password, algorithm); // dummy logic
		}
		return super.getHashedPassword(password, salt, algorithm);
	}

	@Override
	public String generateSalt(String algorithm) {
		if (algorithm.equalsIgnoreCase("Bcrypt")) {
//			return String.valueOf(ThreadLocalRandom.current().nextInt(0, Integer.MAX_VALUE)); // dummy logic
			return BCrypt.gensalt(10);
		}
		return super.generateSalt(algorithm);
	}

}


















