package com.kishore;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;

/**
 * Servlet implementation class check
 */
public class check extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("uiii1111111111111111111");
		out.println("uiii1111111111111111111");
		Criteria c = new Criteria(new Column("RegexDetails", "REGEX_ID"), 1, QueryConstants.EQUAL);
		
		ArrayList<String> demo = new ArrayList<String>();
		
		//String[] demo1 = {"(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)",
			//	"(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<csusername>(-|\\\\w+))(\\\\s)(?<ssitename>(.*\\\\S))(\\\\s)(?<scomputername>(.*\\\\S))(\\\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<sport>(443|80))(\\\\s)(?<csmethod>(GET|POST|get|post))(\\\\s)(?<csuristem>(.*\\\\S))(\\\\s)(?<csuriquery>(-|.*)\\\\S)(\\\\s)(?<scstatus>[0-5]{3})(\\\\s)(?<scwin32status>[0-999]{1,3})(\\\\s)(?<scbytes>.*\\\\S)(\\\\s)(?<csbytes>.*\\\\S)(\\\\s)(?<timetaken>.*\\\\S)(\\\\s)(?<csversion>HTTP/.*\\\\S)(\\\\s)(?<cshost>.*\\\\S)(\\\\s)(?<csUserAgent>.*\\\\S)(\\\\s)(?<csCookie>.*\\\\S)(\\\\s)(?<csReferer>.*\\\\S)"
//};
		
//		demo.add("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)");
//		demo.add("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<csusername>(-|\\\\w+))(\\\\s)(?<ssitename>(.*\\\\S))(\\\\s)(?<scomputername>(.*\\\\S))(\\\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<sport>(443|80))(\\\\s)(?<csmethod>(GET|POST|get|post))(\\\\s)(?<csuristem>(.*\\\\S))(\\\\s)(?<csuriquery>(-|.*)\\\\S)(\\\\s)(?<scstatus>[0-5]{3})(\\\\s)(?<scwin32status>[0-999]{1,3})(\\\\s)(?<scbytes>.*\\\\S)(\\\\s)(?<csbytes>.*\\\\S)(\\\\s)(?<timetaken>.*\\\\S)(\\\\s)(?<csversion>HTTP/.*\\\\S)(\\\\s)(?<cshost>.*\\\\S)(\\\\s)(?<csUserAgent>.*\\\\S)(\\\\s)(?<csCookie>.*\\\\S)(\\\\s)(?<csReferer>.*\\\\S)");

//		Criteria c = new Criteria(new Column("QueryTitle", "TYPE_ID"), 1, QueryConstants.EQUAL);

		DataObject d;
		// ArrayList<String> tempArr = new ArrayList<String>();

		try {

			d = DataAccess.get("RegexDetails", c);
			Iterator<?> it = d.getRows("RegexDetails");
//			Row r = (Row) it.next();
//			String rr = "" + r.get(3);
			
			String line1 = "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73";
		    String pattern = "(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)";  
			
		    String s = "(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<csusername>(-|\\\\w+))(\\\\s)(?<ssitename>(.*\\\\S))(\\\\s)(?<scomputername>(.*\\\\S))(\\\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<sport>(443|80))(\\\\s)(?<csmethod>(GET|POST|get|post))(\\\\s)(?<csuristem>(.*\\\\S))(\\\\s)(?<csuriquery>(-|.*)\\\\S)(\\\\s)(?<scstatus>[0-5]{3})(\\\\s)(?<scwin32status>[0-999]{1,3})(\\\\s)(?<scbytes>.*\\\\S)(\\\\s)(?<csbytes>.*\\\\S)(\\\\s)(?<timetaken>.*\\\\S)(\\\\s)(?<csversion>HTTP/.*\\\\S)(\\\\s)(?<cshost>.*\\\\S)(\\\\s)(?<csUserAgent>.*\\\\S)(\\\\s)(?<csCookie>.*\\\\S)(\\\\s)(?<csReferer>.*\\\\S)";


			while (it.hasNext()) {

				Row r = (Row) it.next();
//				String chart_type = (String) r.get(2);
//				String search_key = (String) r.get(3);
//				String query_type = (String) r.get(4);
//				tempArr.add(chart_type);
//				tempArr.add(search_key);
//				tempArr.add(query_type);
				// tempArr.add((String) r.get(3));
				String cc = "" + r.get(3);
				demo.add(cc);
				out.println("cc vlaue--->" + cc);
				out.println("1");
				if (cc.equals("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<csusername>(-|\\\\w+))(\\\\s)(?<ssitename>(.*\\\\S))(\\\\s)(?<scomputername>(.*\\\\S))(\\\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<sport>(443|80))(\\\\s)(?<csmethod>(GET|POST|get|post))(\\\\s)(?<csuristem>(.*\\\\S))(\\\\s)(?<csuriquery>(-|.*)\\\\S)(\\\\s)(?<scstatus>[0-5]{3})(\\\\s)(?<scwin32status>[0-999]{1,3})(\\\\s)(?<scbytes>.*\\\\S)(\\\\s)(?<csbytes>.*\\\\S)(\\\\s)(?<timetaken>.*\\\\S)(\\\\s)(?<csversion>HTTP/.*\\\\S)(\\\\s)(?<cshost>.*\\\\S)(\\\\s)(?<csUserAgent>.*\\\\S)(\\\\s)(?<csCookie>.*\\\\S)(\\\\s)(?<csReferer>.*\\\\S)")) {
					out.println("String    sssss");
				}
				if (cc.equals(s)) {
					out.println(" pattern  sssss");
				}
				if(Pattern.matches(cc, line1)){
					out.println("kkkkkkkk");
				}
				if(cc.equals(pattern)){
					out.println(" pattern kkkkkkkkkk");
				}
				else {
					out.println("vvvvvvvvvvvvvvvv");
					out.println("2");
				}
				
				
				
				
				
//				else {
//					out.println("nooooooo");
//				}
			

//				System.out.println(it.next());
			}
			
//			out.println("1");
//			int i = 0;
//			while(i<2) {
////				out.println("2");
////				if(Pattern.matches("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<csusername>(-|\\\\w+))(\\\\s)(?<ssitename>(.*\\\\S))(\\\\s)(?<scomputername>(.*\\\\S))(\\\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\\\s)(?<sport>(443|80))(\\\\s)(?<csmethod>(GET|POST|get|post))(\\\\s)(?<csuristem>(.*\\\\S))(\\\\s)(?<csuriquery>(-|.*)\\\\S)(\\\\s)(?<scstatus>[0-5]{3})(\\\\s)(?<scwin32status>[0-999]{1,3})(\\\\s)(?<scbytes>.*\\\\S)(\\\\s)(?<csbytes>.*\\\\S)(\\\\s)(?<timetaken>.*\\\\S)(\\\\s)(?<csversion>HTTP/.*\\\\S)(\\\\s)(?<cshost>.*\\\\S)(\\\\s)(?<csUserAgent>.*\\\\S)(\\\\s)(?<csCookie>.*\\\\S)(\\\\s)(?<csReferer>.*\\\\S)", "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73")) {
////					out.println("3");
////					out.println("ssssssssssssssssssssssssssss");
////					break;
////				} 
////				else {
////					out.println("4");
////					out.println("vvvvvvvvvvvvvvvv");
////					i++;
////				}
////				out.println("5");	
//				
//				String line1 = "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73";
//			    String pattern = "(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)";  
//
//			    String pattern = rr;
//			    i++;
//			    out.println("regex: ____"+pattern);
//			    out.println("type:____"+pattern.getClass().getName());
//			   out.println(Pattern.matches(pattern, line1));
			

		} catch (Exception e) {
			e.printStackTrace();
			out.println("");
		}

	}

}
