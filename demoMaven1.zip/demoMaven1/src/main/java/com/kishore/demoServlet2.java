package com.kishore;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.fasterxml.jackson.core.JsonProcessingException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class DemoServlet2
 */
@MultipartConfig
public class demoServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public String fileName = "";
	public String tempFileName = "";
	public String filePath = "";
	public String text = "";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		ElasticOperations eo = new ElasticOperations();
		
		String temp = request.getParameter("key");
		
//		Integer id = Integer.valueOf(temp);
		
		try {
			Collection<Part> files = request.getParts();

			for (Part part : files) {

				tempFileName = part.getSubmittedFileName();
				filePath = "D:/demomaven2/filesStorage/"+part.getSubmittedFileName();
//				item.write(new File("D:/demomaven2/filesStorage" + item.getName()));
				part.write(filePath);
			}
		} 
		catch (Exception e) {
		}
//		
//		int position = tempFileName.lastIndexOf(".");
//		
//		fileName = tempFileName.substring(0, position);
//		
//		System.out.println(filePath);
		
//		eo.createIndex(fileName);
		
//		text = eo.reader(filePath);
//		System.out.println(text);
//		System.out.println("File uploaded");
		
//		eo.createLog(text , fileName);
//		System.out.println("File indexed in ES");
		
//		if(id == null) {
//			System.out.println("hi");
//		}
//		if(id == 1) {
//			System.out.println("test");
//			text = eo.searchIndex1();
//			System.out.println(text);
//		}
//		if(id == 2) {
//			text = eo.searchIndex2();
//			System.out.println(text);
//		}		
//		System.out.println(text);
		
		try {
//			System.out.println(temp.getClass().getSimpleName());
			text = eo.searchIndex2(temp);
		} catch (JsonProcessingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
//        out.write("File uploaded successfully"
//        		+ "             Now go back to home page for queries.");
        
        System.out.println(temp);
        System.out.println(text);
        out.write(text);
		
//		PrintWriter out = response.getWriter();
//		out.println("uiii1111111111111111111");
//		out.println("uiii1111111111111111111");
	}
}
