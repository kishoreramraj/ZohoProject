package com.kishore;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;



@MultipartConfig
public class demoServlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public String tempFileName = "";
	public String filePath = "";
	public String text = "";
	public String logFormat = "";
	boolean exist = false;
	boolean exist1 = false;
	public String text1 = "";
	public ArrayList<String> demo = new ArrayList<String>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ElasticOperations eo = new ElasticOperations();
		
		logFormat = request.getParameter("logFormat");
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		try {

			Collection<Part> files = request.getParts();

			for (Part part : files) {

				tempFileName = part.getSubmittedFileName();
				filePath = "D:/demomaven2/filesStorage/" + part.getSubmittedFileName();

				File f = new File("D:/demomaven2/filesStorage/" + part.getSubmittedFileName());
				exist = f.exists();

//				item.write(new File("D:/demomaven2/filesStorage" + item.getName()));
				part.write(filePath);
				
				break;

			}
			
			
		} catch (Exception e) {
		}

		if (exist == true) {
			out.println("The file already exists");
		} 
		else{
			
			out.println("inside else");
			
			System.out.println(filePath);
//	eo.createIndex(fileName1);

			out.println("before reader");
			
			text = eo.reader(filePath);
//	System.out.println(text);
			out.println("File uploaded");
			
			out.println("after reader");
			out.println("before create");

			text1 = eo.createLog(text, logFormat);
			
			out.println("after create");
			
			out.println("File indexed in ES");
		}
//		
//		out.println("before demoCall");
//		
//		exist1 = eo.demoCall(logFormat);
//		
//		out.println("after demoCall");

//        System.out.println("1");
//         
//        System.out.println("2");
		out.println("<br>");
		out.println("File :	" + tempFileName + " uploaded successfully! " + "logFormat: "+ logFormat + " array: " + text1);
		out.println("<br>");
		out.println("Click continue to see tables and chart");
		out.println("<br>");
		out.println("<br>");
		out.println("<br><a href=\"http://localhost:4200/demo5/\"><button type=\"button\">continue</button></a>");
//        response.sendRedirect("http://localhost:8080/demo5/"); 
	}
}
