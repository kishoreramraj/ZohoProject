package com.kishore;

import java.io.File;
import java.util.regex.*;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.http.HttpHost;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.ElasticsearchClient;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.Requests;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.RestHighLevelClientBuilder;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
//import org.elasticsearch.index.mapper.ObjectMapper;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram.Bucket;
import org.elasticsearch.search.aggregations.bucket.histogram.HistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.elasticsearch.xcontent.XContentType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ElasticMain {

	public static void main(String[] args) throws IOException, SQLException {

		ElasticOperations obj = new ElasticOperations();
//        obj.createIndex();
//        String  temp = obj.reader();
//        obj.createLog(temp);
//        SearchRequest searchRequest = new SearchRequest();
//        searchRequest.indices("sampleindex");
//        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
//        searchSourceBuilder.query(QueryBuilders.matchAllQuery());
//
//        searchRequest.source(searchSourceBuilder);
//        Map<String, Object> map = null;
//
//        try{
//            SearchResponse searchResponse = null;
//            searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
//            if (searchResponse.getHits().getTotalHits().value > 0) {
//                SearchHit[] searchHit = searchResponse.getHits().getHits();
//                for (SearchHit hit : searchHit) {
//                    map = hit.getSourceAsMap();
//                    System.out.println("Index data:" + Arrays.toString(map.entrySet().toArray()));
//
//                }
//            }
//        }catch (Exception e){
//            System.out.println(e);
//        }

//		 obj.demoCreate();

//		obj.demoCall("windows");

		String kishore = "2019-02-27 00:09:12 86.45.139.254 - W3SVC6 GULLRESWEB 192.168.40.164 80 POST /bkgPremInfo.asp AffiliateID=1&provid=73&postfromresults=1&selNumAdults=2&selNumNights=4&selNumChildren=0&selNumInfants=0&selSharing=1&selEnsuite=N&selArriveDay=24&selArriveMonth=07&selArriveYear=2010&selCurrency=978&strProducts=&strUnits=&SearchSource=5&selAccomType=2&Dtls=False&PremisesCode=SRS0136801&intInterPageSearchType=8&intDirectPremSpecificSearch=10&strDirectSearchRootURL=http%3A//www.irishtourist.com/details/moore_bay_holiday_village2.shtml&tab=price 302 0 89 1540 672 HTTP/1.1 reservations.irishtourist.com Opera/9.64+(Windows+NT+5.1;+U;+pl)+Presto/2.1.1 _11_gob_phase_session_id=APOPVATU4IO2LTKP21LNFTJRA3;+ASPSESSIONIDQAQDDCQD=AIEEJLPDNHENAJODFHBIBIMO http://reservations.irishtourist.com/bkgPremInfo.asp?affiliatevisitid=115048051&AffiliateID=1&provid=73&PremisesCode=SRS0136801\r\n"
				+ "2019-02-27 00:09:13 86.45.139.254 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/js/calendar.js - 200 0 7776 1281 31 HTTP/1.1 reservations.irishtourist.com Opera/9.64+(Windows+NT+5.1;+U;+pl)+Presto/2.1.1 _11_gob_phase_session_id=APOPVATU4IO2LTKP21LNFTJRA3;+ASPSESSIONIDQAQDDCQD=AIEEJLPDNHENAJODFHBIBIMO http://reservations.irishtourist.com/avlAlternativeSearchResults.asp?AffiliateID=1&provid=73&PremisesCode=SRS0136801&Direct=Y&Dtls=False&Available=2&postfromresults=1&selArriveDay=24&selArriveMonth=7&selArriveYear=2010&selNumNights=4&selNumAdults=2&selNumChildren=0&selNumInfants=0&selSharing=1&selEnsuite=N&selCurrency=978&selAccomType=2&hdnLocation=CE,%20%20,K035,0&hdnLocationName=KILKEE&strProducts=&strUnits=&PremisesName=MOORE%20BAY%20HOLIDAY%20VILLAGE%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20&intInterPageSearchType=8&intDirectPremSpecificSearch=10&strDirectSearchRootURL=http%3A//www.irishtourist.com/details/moore_bay_holiday_village2.shtml \r\n";
		
		obj.createLog(kishore, "windows");
//		obj.searchIndex2("1");
		// obj.countData();

		// Always the end statement
		obj.closeIndex();

	}
}

class ElasticOperations {

	RestHighLevelClient client = new RestHighLevelClient(RestClient.builder(new HttpHost("localhost", 9200, "http")));
	public String kishore = "";

//	RestClient httpClient = RestClient.builder(
//		    new HttpHost("localhost", 9200)
//		).build();
//	
//	RestHighLevelClient hlrc = new RestHighLevelClientBuilder(httpClient)
//		    .setApiCompatibilityMode(true) 
//		    .build();
//
//		// Create the Java API Client with the same low level client
//		ElasticsearchTransport transport = new RestClientTransport(
//		    httpClient,
//		    new JacksonJsonpMapper()
//		);

//		ElasticsearchClient esClient = new ElasticsearchClient(transport);

	public void createIndex(String fileName) throws IOException {

		CreateIndexRequest request = new CreateIndexRequest(fileName);
		request.settings(Settings.builder().put("index.number_of_shards", 1).put("index.number_of_replicas", 2));
		CreateIndexResponse createIndexResponse = client.indices().create(request, RequestOptions.DEFAULT);
		System.out.println("response id: " + createIndexResponse.index());
	}

	public String createLog(String tempvar, String logFormat) throws IOException {

		String deli1 = "\\n";
		String deli2 = " ";
		String strresult = "kishore";
		int result = 0;
		String[] lineArr = tempvar.split(deli1);
		int i = 0;

		Database2 db = new Database2();
		ArrayList<String> demo = db.dataFetch2(logFormat);

//		String pattern = "(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)\\r";
//		String line = "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73";
		
		String line = lineArr[0];
		while (i < 2) {

//			Pattern r = Pattern.compile(demo.get(i));
//			Matcher m = r.matcher(line);

			String pattern = demo.get(i);
			if (Pattern.matches(pattern, line)) {
////				result += 1;
				
				SearchRequest searchRequest = new SearchRequest("standardtemplate2");
				SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
				searchSourceBuilder.query(QueryBuilders.matchAllQuery());

				SearchResponse searchResponse = null;
				searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

				long total = searchResponse.getHits().getTotalHits().value;
				long id_no = total;

				for (String temp : lineArr) {

					String[] valueArr = temp.split(deli2);
					Info tempClass = new Info(valueArr);
					IndexRequest indexRequest = new IndexRequest("standardtemplate2");
					indexRequest.id(String.valueOf(id_no));
					indexRequest.source(new ObjectMapper().writeValueAsString(tempClass), XContentType.JSON);
					IndexResponse indexResponse = client.index(indexRequest, RequestOptions.DEFAULT);
//		            System.out.println("response id: " + indexResponse.getId());
//		            System.out.println("response name: " + indexResponse.getResult().name());
					id_no += 1;
//		            System.out.println(tempClass.cs_bytes);
				}
//				System.out.println(demo);
				System.out.println("total: __" + total);
				
				strresult += "The log file indexed successfully  ";
				System.out.println("The log file indexed successfully  ");
				
				break;
			} else {
//				result = 0;
				i++;
				strresult += "Log file not matched regex  ";
				System.out.println("Log file not matched regex  ");
			}
		}

		
		
//		if(result == 1) {
//			
//		}
//		else {
//			
//			return "Log file not matched regex";		
//		}
		
//		return "kishore";
		return strresult;
	}

	public String searchIndex() { // code to retrieve all data from a index

		SearchRequest searchRequest = new SearchRequest("standardtemplate");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(QueryBuilders.matchAllQuery());
//		searchSourceBuilder.aggregation(AggregationBuilders.matchAllQuery().field("c_ip"));

		searchRequest.source(searchSourceBuilder);
		String tempString = null;
		String text = "";
		int i = 0;

		try {
			SearchResponse searchResponse = null;
			searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
			if (searchResponse.getHits().getTotalHits().value > 0) {
				SearchHit[] searchHit = searchResponse.getHits().getHits();
				for (SearchHit hit : searchHit) {
					tempString = hit.getSourceAsString();
					if (i == 0) {
						text = text + tempString;
						System.out.println("Index data:" + tempString);
						i++;
					} else {
						text = text + "," + tempString;
						System.out.println("Index data:" + tempString);
					}
				}
				System.out.println(searchHit.length);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return text;
	}

	// code to retrieve the unique cs_method,c_ip data and their count
	public String searchIndex2(String key) throws JsonProcessingException, SQLException {

		String key1 = key;
		long total = 0;

		Database2 db = new Database2();
		Result resultSet = db.dataFetech1(Integer.valueOf(key));

		String chart_type = resultSet.chart_type;
		String search_key = resultSet.search_key;
		String query_type = resultSet.query_type;
		
		kishore = query_type;

		System.out.println(chart_type);
		System.out.println(search_key);
		System.out.println(query_type);

		SearchRequest searchRequest = new SearchRequest("standardtemplate2");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

		if (query_type.equals("term")) {
			TermsAggregationBuilder a = AggregationBuilders.terms("DISTINCT_VALUES").field(search_key).size(1000)
					.order(BucketOrder.key(true));
			searchSourceBuilder.aggregation(a);
		} else if (query_type.equals("histrogram")) {
			HistogramAggregationBuilder b = AggregationBuilders.histogram("DISTINCT_VALUES").field(search_key)
					.interval(500);
			searchSourceBuilder.aggregation(b);
		}

//		searchSourceBuilder.query(QueryBuilders.matchAllQuery());
		// searchSourceBuilder.aggregation(a);

//		HistogramAggregationBuilder b = AggregationBuilders.histogram("DISTINCT_VALUES").field("cs_bytes").interval(500);
//		searchSourceBuilder.aggregation(b);

		System.out.println("searchSourceBuilder: ____" + searchSourceBuilder);
		searchRequest.source(searchSourceBuilder);

		ArrayList<MapClass> arr = new ArrayList<MapClass>();
		ArrayList<String> arr1 = new ArrayList<String>();
		MapClass tempClass = new MapClass(search_key, "count");
		MapClass tempClass1 = new MapClass(chart_type, "chart");

		try {

			SearchResponse searchResponse = null;
			searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
			total = searchResponse.getHits().getTotalHits().value;
			System.out.println("total:__" + total);

			if (searchResponse.getHits().getTotalHits().value > 0) {

				Aggregations aggregations = searchResponse.getAggregations();
				if (query_type.equals("term")) {
					Terms aggTerms = aggregations.get("DISTINCT_VALUES");
					List<? extends Terms.Bucket> buckets = aggTerms.getBuckets();
					for (Terms.Bucket bucket : buckets) {

						MapClass tempClass2 = new MapClass(bucket.getKeyAsString(),
								String.valueOf(bucket.getDocCount()));
						arr.add(tempClass2);
						arr1.add(bucket.getKeyAsString());
					}
				} else if (query_type.equals("histrogram")) {
					Histogram aggTerms = aggregations.get("DISTINCT_VALUES");
					List<? extends Histogram.Bucket> buckets = aggTerms.getBuckets();
					for (Histogram.Bucket bucket : buckets) {

						MapClass tempClass2 = new MapClass(bucket.getKeyAsString(),
								String.valueOf(bucket.getDocCount()));
						arr.add(tempClass2);
						arr1.add(bucket.getKeyAsString());
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		arr.add(0, tempClass);
		arr.add(0, tempClass1);
		String json = new ObjectMapper().writeValueAsString(arr);
		System.out.println("The count is: __" + arr1);
		System.out.println("The json is: __" + json);

		return json;
	}

	public void countData() throws IOException {

		CountRequest countRequest = new CountRequest("sampleindex");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(QueryBuilders.matchQuery("time", "00:01:43"));
		countRequest.source(searchSourceBuilder);

		CountResponse countResponse = client.count(countRequest, RequestOptions.DEFAULT);

		long count = countResponse.getCount();
		System.out.println(count);
	}

	public void closeIndex() throws IOException {
		client.close();
	}

	public String reader(String path) {

//        File tempFile = new File("E:\\u_ex15AprFri201716.log");
//        String path = String.valueOf(tempFile.getAbsoluteFile());
//        String temp = reader(path);
		String tempString = null;
		try {
			String file = path;
			Scanner scanner = new Scanner(new File(file));
			scanner.useDelimiter("\\Z");
//            System.out.println(scanner.next());  	//used to print the file contents
			tempString = scanner.next();
			scanner.close();
		} catch (Exception e) {
			System.out.println(e);
		}
//        System.out.println("IN READER");
//        System.out.println(tempString);
		return tempString;
	}

	public void demoCreate() throws IOException {

		String deli1 = "\\n";
		String deli2 = " ";

		SearchRequest searchRequest = new SearchRequest("demo5");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(QueryBuilders.matchAllQuery());

		SearchResponse searchResponse = null;
		searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

		long total = searchResponse.getHits().getTotalHits().value;
		long id_no = total;
		String[] names = { "kishore", "jeeva" };
		String[] fields = { "name", "age" };
		int[] age = { 21, 20 };

		HashMap<String, String> hm = new HashMap<>();
		ArrayList<String> l = new ArrayList<>();
		String[] temp1 = { "viky", "22" };
		for (int i = 0; i < 2; i++) {
			hm.put(fields[i], temp1[i]);
		}

		IndexRequest indexRequest = new IndexRequest("demo5");

//		for(int i=0; i<2; i++) {
//			hm.put("name", names[i]);
//			hm.put("age", String.valueOf(age[i]));
//			indexRequest.id(String.valueOf(id_no));
//			indexRequest.source(new ObjectMapper().writeValueAsString(hm), XContentType.JSON);
//			IndexResponse indexResponse = client.index(indexRequest, RequestOptions.DEFAULT);
//			id_no += 1;
//		}

		indexRequest.id(String.valueOf(id_no));
		indexRequest.source(new ObjectMapper().writeValueAsString(hm), XContentType.JSON);
		IndexResponse indexResponse = client.index(indexRequest, RequestOptions.DEFAULT);
		id_no += 1;

////            System.out.println("response id: " + indexResponse.getId());
////            System.out.println("response name: " + indexResponse.getResult().name());
////            System.out.println(tempClass.cs_bytes);
////		System.out.println("IN CREATE");

		System.out.println("total: __" + total);
	}

	public boolean demoCall(String logFormat) {

//		int i = 0;
//		String result = "kishore ", pattern = "";
//		
		Database2 db = new Database2();
		String type = "";
		ArrayList<String> demo = new ArrayList<String>();
		demo = db.dataFetch2(logFormat);
		
//		String line = "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73";
//
//		while (i < demo.size()) {
//
////			Pattern r = Pattern.compile(demo.get(i));
////			Matcher m = r.matcher(line);
//
//			pattern = demo.get(i);
//
//			if (Pattern.matches(pattern, line)) {
//				result += " present at";
//				break;
//			} else {
//				i++;
//				continue;
//			}
//		}
//
//		return result+i;

		// String pattern =
		// "(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)";

		int i = 0;

		String result = "";

//		Database2 db = new Database2();
//		ArrayList<String> demo = db.dataFetch2(logFormat);

//		ArrayList<String> demo = new ArrayList<String>();

//		demo.add("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\\\s)");
//		demo.add("(?<csmethod>GET|POST|get|post)");
//		demo.add("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)");

		String line = "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73";
		String pattern = demo.get(1);
		
//		String line1 = "2019-02-27 ";
//		System.out.println(demo);
//		
//		ElasticOperations e = new ElasticOperations();
//		result = e.kish(demo);

//		while (i < demo.size()) {
//
//			pattern  = demo.get(i);
//			if (Pattern.matches(pattern , line)) {
////				System.out.println("matches");
//				result += "matches";
//				break;
//			} else {
//				i++;
////				System.out.println("not matches");
//			}
//		}

//		System.out.println(result + "____" + demo.get(2).length() + "____" + demo.get(2));
		
		String s2="(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)";
		String s3="(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)";

		String kis = "term";

//		return pattern.equals("(?<date>[0-9]{4}-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[12][0-9]|3[01]))(\\s)(?<time>([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])(\\s)(?<cip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<csusername>(-|\\w+))(\\s)(?<ssitename>(.*\\S))(\\s)(?<scomputername>(.*\\S))(\\s)(?<sip>(((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5])[.]){3}((0|1)?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(\\s)(?<sport>(443|80))(\\s)(?<csmethod>(GET|POST|get|post))(\\s)(?<csuristem>(.*\\S))(\\s)(?<csuriquery>(-|.*)\\S)(\\s)(?<scstatus>[0-5]{3})(\\s)(?<scwin32status>[0-999]{1,3})(\\s)(?<scbytes>.*\\S)(\\s)(?<csbytes>.*\\S)(\\s)(?<timetaken>.*\\S)(\\s)(?<csversion>HTTP/.*\\S)(\\s)(?<cshost>.*\\S)(\\s)(?<csUserAgent>.*\\S)(\\s)(?<csCookie>.*\\S)(\\s)(?<csReferer>.*\\S)");
	
		return Pattern.matches(pattern, line);
	}

	public String kish(ArrayList<String> demo) {

		
		int i=0;
		ArrayList<String> demo1 = new ArrayList<String>();
		demo1 = demo;
		
		String result = "";
		String line = "2019-02-27 00:15:39 89.125.85.26 - W3SVC6 GULLRESWEB 192.168.40.164 80 GET /inc/css/buttons.css - 200 0 6845 584 2016 HTTP/1.1 reservations.irishtourist.com Mozilla/5.0+(Windows;+U;+Windows+NT+6.0;+en-US;+rv:1.9.1.9)+Gecko/20100315+Firefox/3.5.9 _11_gob_phase_session_id=FQ0A7UFV4B2147VQP2TGVA0B80;+ASPSESSIONIDQAQDDCQD=CIEEJLPDHIGBFFCICEDFBLIM http://reservations.irishtourist.com/avlSearchResults.asp?affiliatevisitid=999999999&AffiliateID=1&ProvID=73";
		
		while (i < demo.size()) {

			if (Pattern.matches(demo1.get(i), line)) {
//				System.out.println("matches");
				result += "matches";
				break;
			} else {
				i++;
//				System.out.println("not matches");
			}
		}

		System.out.println(result + "____" + demo.get(2).length() + "____" + demo.get(2));

		return result + "____" + demo1.get(2).length() + "____" + demo1.get(2);
	}
}

class Info {

	public String date = null;
	public String time = null;
	public String c_ip = null;
	public String cs_username = null;
	public String s_sitename = null;
	public String s_computername = null;
	public String s_ip = null;
	public Integer s_port = null;
	public String cs_method = null;
	public String cs_uri_stem = null;
	public String cs_uri_query = null;
	public Integer sc_status = null;
	public Integer sc_win32_status = null;
	public Integer sc_bytes = null;
	public Integer cs_bytes = null;
	public Integer time_taken = null;
	public String cs_version = null;
	public String cs_host = null;
	public String cs_User_Agent = null;
	public String cs_Cookie = null;
	public String cs_Referer = null;

	public Info(String[] var) {

		this.date = var[0];
		this.time = var[1];
		this.c_ip = var[2];
		this.cs_username = var[3];
		this.s_sitename = var[4];
		this.s_computername = var[5];
		this.s_ip = var[6];
		this.s_port = Integer.valueOf(var[7]);
		this.cs_method = var[8];
		this.cs_uri_stem = var[9];
		this.cs_uri_query = var[10];
		this.sc_status = Integer.valueOf(var[11]);
		this.sc_win32_status = Integer.valueOf(var[12]);
		this.sc_bytes = Integer.valueOf(var[13]);
		this.cs_bytes = Integer.valueOf(var[14]);
		this.time_taken = Integer.valueOf(var[15]);
		this.cs_version = var[16];
		this.cs_host = var[17];
		this.cs_User_Agent = var[18];
		this.cs_Cookie = var[19];
		this.cs_Referer = var[20];
	}
}

class MapClass {
	public String key;
	public String value;

	public MapClass(String key, String value) {
		this.key = key;
		this.value = value;
	}
}
